var x = lbl(true, 'secret');

if (x) print(true); else print(false);

