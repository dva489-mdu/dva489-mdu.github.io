var x = lbl(true, 'secret');
var y = x;

print(x);
print(y);

