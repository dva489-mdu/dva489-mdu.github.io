# JSFlow 
[![Build Status](https://semaphoreci.com/api/v1/projects/ec57d3d7-dc77-4698-8159-7ad097cc01e2/700294/badge.svg)](https://semaphoreci.com/lbello/jsflow)
JSFlow is an information flow aware JavaScript interpeter written in JavaScript.

# Installation 
For installing, download and untar jsflow-1.1.0.tgz. Install the dependencies with `npm install`. Then, run `./jsflow`

# Contributors

* Daniel Hedin
* Alexander Sjösten
* Andrei Sabelfeld 

Former contributors:

* Arnar Birgisson
* Luciano Bello
