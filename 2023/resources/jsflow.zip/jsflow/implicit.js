var x = lbl(true, 'secret');
var y;

if (x) y = true; else y = false;

print(x);
print(y);

